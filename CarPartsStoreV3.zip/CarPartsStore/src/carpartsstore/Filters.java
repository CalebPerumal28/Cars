/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.Scanner;

    public class Filters extends Product {
        Scanner kb = new Scanner(System.in);

    public Filters(CarPartsStore cps) {
        super(cps);
    }
    
    public void airFilters() {
        String [] airFilterBrands = {"Blue Print", "GUD", "K&N Filters", "MAHLE GmbH", "MANN-FILTER", "topran"};
        boolean correctAirF = false;
        
        while (!correctAirF) {
        System.out.println("Please select air filter brand:");
        System.out.println("1.Blue Print\t2.GUD\t3.K&N Filters\t4.MAHLE GmbH\t5.MANN-FILTER\t6.topran");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(airFilterBrands[0]); correctAirF = true; break;
                case 2:
                    brand.add(airFilterBrands[1]); correctAirF = true; break;
                case 3:
                    brand.add(airFilterBrands[2]); correctAirF = true; break;
                case 4:
                    brand.add(airFilterBrands[3]); correctAirF = true; break;
                case 5:
                    brand.add(airFilterBrands[4]); correctAirF = true; break;
                case 6:
                    brand.add(airFilterBrands[5]); correctAirF = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void oilFilters () {
        String [] oilFilterBrands = {"Blue Print", "Bosch GmbH", "FEBI-Bilstein Gmbh", "MAHLE GmbH", "MANN-FILTER", "topran"};
        boolean correctOilF = false;
        
        while (!correctOilF) {
        System.out.println("Please select oil filter brand:");
        System.out.println("1.Blue Print\t2.Bosch\t3.FEBI-Bilstein Gmbh\t4.MAHLE GmbH\t5.MANN-FILTER\t6topran");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(oilFilterBrands[0]); correctOilF = true; break;
                case 2:
                    brand.add(oilFilterBrands[1]); correctOilF = true; break;
                case 3:
                    brand.add(oilFilterBrands[2]); correctOilF = true; break;
                case 4:
                    brand.add(oilFilterBrands[3]); correctOilF = true; break;
                case 5:
                    brand.add(oilFilterBrands[4]); correctOilF = true; break;
                case 6:
                    brand.add(oilFilterBrands[5]); correctOilF = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void filtersMenu() {
        boolean filtersBoolean = false;
        
        while(!filtersBoolean) {
        System.out.println("Please select a category:\n"
                + "1.Air Filters\n"
                + "2.Oil Filters");
        int filterChoice = kb.nextInt();
        
        switch(filterChoice) {
                case 1:
                    airFilters(); filtersBoolean = true; break;
                case 2:
                    oilFilters(); filtersBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
          }
        }
    }
