/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

public class CarPartsStore {
    Scanner kb = new Scanner(System.in);

    public static void main(String[] args) {
        CarPartsStore cps = new CarPartsStore();

        System.out.println("*****GOLDWAGEN PARTSFINDER*****");
        System.out.println("-------------------------------");
        cps.mainMenu();
    }

    public void mainMenu() {
        Account acc = new Account(this); // Pass the CarPartsStore instance to the Account constructor
        boolean menuMain = false;

        while (!menuMain) {
            System.out.println("Please select an option:\n"
                + "1. Register \n"
                + "2. Login");
            int choiceOne = kb.nextInt();

            switch (choiceOne) {
                case 1:
                    acc.RegisterUsername(); menuMain = true; break;
                case 2:
                    acc.Login(); menuMain = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!"); break;
            }
        }
    }

    public void menuOne() {
        boolean menuOne = false;
        Product product = new Product(this);
        
        while (!menuOne) {
        System.out.println("Please select an option:\n"
                + "1.Add a part\n"
                + "2.Search for a part\n"
                + "3.Display all parts\n"
                + "4.Exit");
        int choiceTwo = kb.nextInt();
        
        switch (choiceTwo) {
            case 1:
                addParts();
                break;
            case 2:
                product.searchPart();
                break;
            case 3:
                product.displayParts();
                break;    
            case 4:
                exit();
                menuOne = true; // Exit the loop when the user chooses to exit
                break;
            default:
                System.out.println("Incorrect input!! Please enter a valid option.");
                break;
        }
      }
    }
    
    public void addParts() {
        boolean menuParts = false;
        Suspension suspension = new Suspension(this);
        Lubricants lubricants = new Lubricants(this);
        Filters filters = new Filters(this);
        Engine engine = new Engine(this);
        DriveTrain drive = new DriveTrain(this);
        
        while (!menuParts) {
        System.out.println("Please select the department you are adding to:\n"
                + "1. Suspension Components\n"
                + "2. Lubricants\n"
                + "3. Filters\n"
                + "4. Engine Components\n"
                + "5. DriveTrain Components");
        int prdctChoice = kb.nextInt();
        
        switch (prdctChoice) {
                case 1:
                    suspension.suspensionMenu(); menuParts = true; break;
                case 2:
                    lubricants.lubricantsMenu(); menuParts = true; break;
                case 3:
                    filters.filtersMenu(); menuParts = true; break; 
                case 4:
                    engine.engineMenu(); menuParts = true; break; 
                case 5:
                    drive.drivetrainMenu(); menuParts = true; break; 
                default:
                    System.out.println("Incorrect input!! Please enter a valid option."); break;
            }
        }
    }
    
    public void exit() {
        System.out.println("---------------------------------------------------");
        System.out.println("*****THANK YOU FOR USING GOLDWAGEN PARTSFINDER******");
        System.exit(0);
    }
}

