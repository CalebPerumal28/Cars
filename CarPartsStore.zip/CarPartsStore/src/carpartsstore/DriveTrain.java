/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class DriveTrain extends Product {
    Scanner kb = new Scanner(System.in);
    
    public void clutchKits() {
        String [] clutchBrands = {"Blue Print", "LuK", "ZF SACHS", "Schaeffler Group"};
        boolean correctCK = false;
        
        while (!correctCK) {
        System.out.println("Please select clutch kit brand:");
        System.out.println("1.Blue Print\t2.LuK\t3.ZF SACHS\t4.Schaeffler Group");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    suspension.productBrand(clutchBrands[0]); correctCK = true; break;
                case 2:
                    suspension.productBrand(clutchBrands[1]); correctCK = true; break;
                case 3:
                    suspension.productBrand(clutchBrands[2]); correctCK = true; break;
                case 4:
                    suspension.productBrand(clutchBrands[3]); correctCK = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
        super.generalPart();
    }
    
    public void flywheels() {
        String [] flywheelBrands = {"LuK", "ZF SACHS", "Schaeffler Group"};
        boolean correctFly = false;
        
        while (!correctFly) {
        System.out.println("Please select flywheel brand:");
        System.out.println("1.LuK\t2.ZF SACHS\t3.Schaeffler Group");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    suspension.productBrand(flywheelBrands[0]); correctFly = true; break;
                case 2:
                    suspension.productBrand(flywheelBrands[1]); correctFly = true; break;
                case 3:
                    suspension.productBrand(flywheelBrands[2]); correctFly = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
        super.generalPart();
    }
}
