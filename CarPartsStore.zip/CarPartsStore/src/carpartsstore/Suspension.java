/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Suspension extends Product {
    Scanner kb = new Scanner(System.in);
    
    public void shockAbsorber() {
        String [] shockAbsorberBrands = {"Bilstein Corporate", "KYB Corporation", "Monroe", "ZF SACHS", "Öhlins Racing AB"};
        boolean correctSA = false;
        
        while (!correctSA) {
        System.out.println("Please select shock absorber brand:");
        System.out.println("1.Bilstein Corporate\t2.KYB Corporation\t3.Monroe\t4.ZF SACHS\t5.Öhlins Racing AB");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    suspension.productBrand(shockAbsorberBrands[0]); correctSA = true; break;
                case 2:
                    suspension.productBrand(shockAbsorberBrands[1]); correctSA = true; break;
                case 3:
                    suspension.productBrand(shockAbsorberBrands[2]); correctSA = true; break;
                case 4:
                    suspension.productBrand(shockAbsorberBrands[3]); correctSA = true; break;
                case 5:
                    suspension.productBrand(shockAbsorberBrands[4]); correctSA = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
        super.generalPart();
    }
    
    public void coilovers() {
        String [] coiloverBrands = {"BC Racing", "Bilstein Corporate", "Eibach GmbH", "H&R", "KW Suspensions, Inc.", "Öhlins Racing AB"};
        
        boolean correctCoil = false;
        
        while (!correctCoil) {
        System.out.println("Please select coilover brand:"
                + "1.BC Racing\t2.Bilstein Corporate\t3.Eibach GmbH\t4.H&R\t5.KW Suspension, Inc.\t6.Öhlins Racing AB");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    suspension.productBrand(coiloverBrands[0]); correctCoil = true; break;
                case 2:
                    suspension.productBrand(coiloverBrands[1]); correctCoil = true; break;
                case 3:
                    suspension.productBrand(coiloverBrands[2]); correctCoil = true; break;
                case 4:
                    suspension.productBrand(coiloverBrands[3]); correctCoil = true; break;
                case 5:
                    suspension.productBrand(coiloverBrands[4]); correctCoil = true; break;
                case 6:
                    suspension.productBrand(coiloverBrands[5]); correctCoil = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
        super.generalPart();
    }
}
