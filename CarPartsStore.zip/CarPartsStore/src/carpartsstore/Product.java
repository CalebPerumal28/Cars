/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Product {
    Scanner kb = new Scanner(System.in);
    Suspension suspension = new Suspension();
    
    private static final ArrayList<String> brand = new ArrayList<>();
    private static final ArrayList<Double> price = new ArrayList<>();
    private static final ArrayList<Integer> quantity = new ArrayList<>();
    private static final ArrayList<String> manufacturer = new ArrayList<>();
    private static final String [] manufacturerChoice = {"Audi", "BMW", "Ford", "Hyundai", "Kia", "Mercedes-Benz", "Porsche", "Toyota", "Volkswagen"};
    private static final ArrayList<String> model = new ArrayList<>();
    private static final ArrayList<String> description = new ArrayList<>();
    private static final ArrayList<String> code = new ArrayList<>();
    
    public void productBrand(String brandName) {
        brand.add(brandName);
    }
    
    public void generalPart() {
        System.out.println("Enter product price:");
        double prdctPrice = kb.nextDouble();
        price.add(prdctPrice);
        
        System.out.println("Enter product quantity:");
        int prdctQuantity = kb.nextInt();
        quantity.add(prdctQuantity);
        
        System.out.println("Select manufacturer:");
        System.out.println("1.Audi\t2.BMW\t3.Ford\t4.Hyundai\t5.Kia\t6.Mercedes-Benz\t7.Porsche\t8.Toyota\t9.Volkswagen");
        int manuChoice = kb.nextInt();
        boolean manuBoolean = false;
        
        while (!manuBoolean) {
        switch (manuChoice) {
                case 1:
                    manufacturer.add(manufacturerChoice[0]); manuBoolean = true; break;
                case 2:
                    manufacturer.add(manufacturerChoice[1]); manuBoolean = true; break;
                case 3:
                    manufacturer.add(manufacturerChoice[2]); manuBoolean = true; break;
                case 4:
                    manufacturer.add(manufacturerChoice[3]); manuBoolean = true; break;
                case 5:
                    manufacturer.add(manufacturerChoice[4]); manuBoolean = true; break;
                case 6:
                    manufacturer.add(manufacturerChoice[5]); manuBoolean = true; break;
                case 7:
                    manufacturer.add(manufacturerChoice[6]); manuBoolean = true; break;
                case 8:
                    manufacturer.add(manufacturerChoice[7]); manuBoolean = true; break;
                case 9:
                    manufacturer.add(manufacturerChoice[8]); manuBoolean = true; break;
                case 10:
                    manufacturer.add(manufacturerChoice[9]); manuBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
        
        System.out.println("Enter manufacturer model:");
        String manuModel = kb.next();
        model.add(manuModel);
        
        System.out.println("Enter product description:");
        String prdctDesc = kb.next();
        description.add(prdctDesc);
        
        boolean codeChar = false;
        while(!codeChar) {
            System.out.println("Code must be 8 charcters or less.\n"
                + "Enter product code:");
        String prdctCode = kb.next().toUpperCase();
        
            if ((prdctCode.length()>0) && (prdctCode.length()<=8))
            {
                code.add(prdctCode);
                codeChar = true;
            }
            else if (prdctCode.length()<=0)
            {
                System.out.println("You have not entered a code. Please try again...");
            }
            else if ((prdctCode.length()>8)) 
            {
                System.out.println("Your code is too long. Please try again...");
            }
        }
    }
    
}
