/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carpartsstore;

import java.util.Scanner;

public class CarPartsStore {
    Scanner kb = new Scanner(System.in);

    public static void main(String[] args) {
        CarPartsStore cps = new CarPartsStore();

        System.out.println("Welcome to Goldwagen Partsfinder!");
        cps.mainMenu();
    }

    public void mainMenu() {
        Account acc = new Account(this); // Pass the CarPartsStore instance to the Account constructor
        boolean menuMain = false;

        while (!menuMain) {
            System.out.println("Please select an option:\n"
                + "1. Register \n"
                + "2. Login");
            int choiceOne = kb.nextInt();

            switch (choiceOne) {
                case 1:
                    acc.RegisterUsername(); menuMain = true; break;
                case 2:
                    acc.Login(); menuMain = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
    }

    public void menuOne() {
        boolean menuOne = false;
        
        while (!menuOne) {
        System.out.println("Please select an option:"
                + "1. Add parts"
                + "2. Search for parts"
                + "3. Exit");
        int choiceTwo = kb.nextInt();
        
        switch(choiceTwo) {
            case 1:
                addParts();menuOne = true; break;
            case 2:
                    
            case 3:
                
            default:
                System.out.println("Incorrect input. Please enter a valid option."); break;
        }
      }
    }
    
    public void addParts() {
        boolean menuParts = false;
        Product product = new Product();
        
        while (!menuParts) {
        System.out.println("Please select the department you are adding to:"
                + "1. Suspension Components"
                + "2. Lubricants"
                + "3. Filters"
                + "4. Engine Components"
                + "5. DriveTrain Components");
        int prdctChoice = kb.nextInt();
        
        switch (prdctChoice) {
                case 1:
                    ; menuParts = true; break;
                case 2:
                    ; menuParts = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option."); break;
            }
        }
    }
    
    public void exit() {
        System.out.println("Thank you for using this program, goodbye!");
    }
}

