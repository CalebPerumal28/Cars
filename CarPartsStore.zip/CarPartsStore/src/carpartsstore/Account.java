/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

public class Account {
    Scanner kb = new Scanner(System.in);
    CarPartsStore cps;
    
    private static final ArrayList<String> firstname = new ArrayList<>();
    private static final ArrayList<String> lastname = new ArrayList<>();
    private static final ArrayList<String> username = new ArrayList<>();
    private static final ArrayList<String> password = new ArrayList<>();

    // Constructor that takes a CarPartsStore instance as a parameter
    public Account(CarPartsStore cps) {
        this.cps = cps;
    }
    
    public void RegisterUsername() {
        this.Registration();
        boolean correctUsername = false;
        
        System.out.println("Username must contain between 1-30 characters. May include periods and underscores, but no special characters.\n"
                    + "Enter your username:");

        while (!correctUsername) {
            String employeeUsername = kb.next().toLowerCase();    
            
            if (employeeUsername.matches("^[a-zA-Z0-9._]+$") && employeeUsername.length() >= 1 && employeeUsername.length() <= 30) {
                System.out.println("Username captured successfully.");
                username.add(employeeUsername);
                correctUsername = true;
                this.RegisterPassword();
            } else {
                System.out.println("Username does not meet requirements.\n"
                        + "Please ensure username contains between 1-30 characters. May include periods and underscores, but no special characters.");
            }
        }
    }


    public void RegisterPassword() {
        boolean correctPassword = false;
        
        System.out.println("Passwords must contain at least 6 characters, a capital letter & a number..\n"
                    + "Please enter a password:");
        
        while(!correctPassword) {  
            String employeePassword = kb.next();
            
            if ((employeePassword.length() >= 6) && (employeePassword.matches(".*[A-Z].*")) && (employeePassword.matches(".*\\d.*")))
                {
                    System.out.println("Password captured successfully.");
                    password.add(employeePassword);
                    System.out.println("Account created successfully.");
                    correctPassword = true;
                    cps.mainMenu();
            } else {
                    System.out.println("Password does not meet requirements.\n"
                            + "Please ensure your password must contain at least 6 characters, a capital letter & a number.");
                }
           }
    }
    
    public void Registration() {
        System.out.println("Enter your first name:");
        String name = kb.next();
        firstname.add(name);
        
        System.out.println("Enter your last name:");
        String surname = kb.next();
        lastname.add(surname);
    }
    
    public void Login() {
        if (username.isEmpty() || password.isEmpty())
            {
                System.out.println("No employees registered.");
                System.out.println("Please register first to continue.");
                cps.mainMenu();
            }
        
        int loginAttempts = 3;

        boolean loggedIn = false;

        while (!loggedIn && loginAttempts > 0) {
            System.out.println("Enter your username:");
            String loginUsername = kb.next();
            System.out.println("Enter your password:");
            String loginPassword = kb.next();

            for (int i = 0; i < username.size(); i++) {
                if (loginUsername.equals(username.get(i)) && loginPassword.equals(password.get(i))) {
                    System.out.println("Welcome " + firstname.get(i) + " " + lastname.get(i) + ", it is great to see you again!");
                    loggedIn = true;
                    cps.menuOne();
                    break;
                }
            }

            if (!loggedIn) {
                System.out.println("It seems you have entered the wrong username or password, please try again\n"
                        + "You have " + (loginAttempts - 1) + " login attempts left");
                loginAttempts--;
            }

            if (loginAttempts == 0) {
                System.out.println("Your account has been locked\n"
                        + "Please contact your administrator");
                cps.exit();
            }
        }
    }

    
}
